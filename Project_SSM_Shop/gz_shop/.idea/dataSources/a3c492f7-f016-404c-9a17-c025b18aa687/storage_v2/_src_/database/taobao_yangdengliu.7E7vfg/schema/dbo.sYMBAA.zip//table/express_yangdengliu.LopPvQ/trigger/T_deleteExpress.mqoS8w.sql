create trigger T_deleteExpress
on dbo.express_yangdengliu
instead of delete
as begin
	declare @accept int
	select @accept=accept from deleted
	if @accept=1
		begin
			print '删除成功'
			delete from express_yangdengliu
					from express_yangdengliu e,deleted d where e.eid=d.eid
		end
	else
		print '没有删除'
end
go

