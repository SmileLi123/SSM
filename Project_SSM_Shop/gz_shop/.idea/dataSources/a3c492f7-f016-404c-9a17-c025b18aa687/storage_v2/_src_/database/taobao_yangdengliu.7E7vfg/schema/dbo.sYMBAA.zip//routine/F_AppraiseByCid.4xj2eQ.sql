create function F_AppraiseByCid(@id int)
returns @seeAppraise table(
	aid int,uid int,cid int, describe nvarchar(50),date datetime,uname nvarchar(32),cname nvarchar(32)
)
as begin
	declare @aid int,@uid int,@cid int, @describe nvarchar(50),@date datetime,@uname nvarchar(32),@cname nvarchar(32)
	declare cur_see cursor
	for	
	select a.aid,a.uid,a.cid,a.describe,a.date,u.uname,c.cname 
	from appraise_yangdengliu a
	join commodity_yangdengliu c on a.cid=c.cid
	join user_yangdengliu u on u.uid=a.cid
	where a.cid=@id
	open cur_see
	fetch next from cur_see into @aid,@uid,@cid,@describe,@date,@uname,@cname 
	while @@FETCH_STATUS=0
	begin
		insert into @seeAppraise
			select a.aid,a.uid,a.cid,a.describe,a.date,u.uname,c.cname 
			from appraise_yangdengliu a
			join commodity_yangdengliu c on a.cid=c.cid
			join user_yangdengliu u on u.uid=a.cid
		fetch next from cur_see into @aid,@uid,@cid,@describe,@date,@uname,@cname 
	end
	close cur_see
	deallocate cur_see
	return 
end
go

