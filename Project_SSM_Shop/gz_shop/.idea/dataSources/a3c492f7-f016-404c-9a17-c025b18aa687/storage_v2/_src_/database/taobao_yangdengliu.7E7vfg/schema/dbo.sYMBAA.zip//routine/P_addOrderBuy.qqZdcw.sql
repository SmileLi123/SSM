create PROC P_addOrderBuy(@num int=1,@id int)
as
begin
begin tran
if @num < (select num from commodity_yangdengliu c)
	begin
	rollback tran
	end
update order_yangdengliu set buy=@num where oid=@id;
insert into express_yangdengliu(oid,addr,date) 
select o.oid ,s.address,GETDATE()
from order_yangdengliu as o 
join commodity_yangdengliu c on o.cid=c.cid
join shopkeeper_yangdengliu s on s.sid=c.sid
where o.oid=@id
commit tran
end
go

