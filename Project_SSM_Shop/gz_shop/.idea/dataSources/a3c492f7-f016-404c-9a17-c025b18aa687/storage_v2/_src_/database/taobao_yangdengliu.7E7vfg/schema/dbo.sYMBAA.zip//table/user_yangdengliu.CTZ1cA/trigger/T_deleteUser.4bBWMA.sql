create trigger T_deleteUser
on user_yangdengliu 
for delete
as begin
	declare @send int, @accept int
	select @send=COUNT(1) from express_yangdengliu e,deleted d ,order_yangdengliu o
		where e.oid=o.oid and o.uid=d.uid and e.send=1
	select @accept=COUNT(1) from express_yangdengliu e,deleted d ,order_yangdengliu o
		where e.oid=o.oid and o.uid=d.uid and e.accept=1
	if @send=@accept
	begin
		delete from express_yangdengliu
			from express_yangdengliu e ,order_yangdengliu o ,deleted d
			where e.oid=o.oid and d.uid=o.uid
		delete from order_yangdengliu
			from order_yangdengliu o,deleted d
			where o.uid=d.uid
	end
	else
		rollback tran
end
go

