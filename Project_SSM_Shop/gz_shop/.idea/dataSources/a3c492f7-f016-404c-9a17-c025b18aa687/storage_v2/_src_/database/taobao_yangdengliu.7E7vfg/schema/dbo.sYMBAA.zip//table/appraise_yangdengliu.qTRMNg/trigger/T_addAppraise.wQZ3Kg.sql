create trigger T_addAppraise
on appraise_yangdengliu for insert
as begin
	declare @accept int
	select @accept=e.accept 
		from express_yangdengliu e ,inserted i,order_yangdengliu o
		where i.uid=o.uid and o.oid=e.oid and i.cid=o.cid
	if @accept<>1
	begin
		print '商品还没到'
		rollback tran
	end
end
go

