CREATE VIEW dbo.queryExpressByUser
AS
SELECT     dbo.commodity_yangdengliu.cname, dbo.commodity_yangdengliu.price, dbo.commodity_yangdengliu.describe, dbo.shopkeeper_yangdengliu.sname, dbo.order_yangdengliu.buy, 
                      dbo.user_yangdengliu.home, dbo.express_yangdengliu.saddr, dbo.express_yangdengliu.send, dbo.express_yangdengliu.accept, dbo.express_yangdengliu.date, dbo.user_yangdengliu.uid
FROM         dbo.commodity_yangdengliu INNER JOIN
                      dbo.order_yangdengliu ON dbo.commodity_yangdengliu.cid = dbo.order_yangdengliu.cid INNER JOIN
                      dbo.express_yangdengliu ON dbo.order_yangdengliu.oid = dbo.express_yangdengliu.oid INNER JOIN
                      dbo.shopkeeper_yangdengliu ON dbo.commodity_yangdengliu.sid = dbo.shopkeeper_yangdengliu.sid INNER JOIN
                      dbo.user_yangdengliu ON dbo.order_yangdengliu.uid = dbo.user_yangdengliu.uid
go

