create trigger T_deleteOrder
on dbo.order_yangdengliu for delete
as begin
delete from express_yangdengliu
from deleted d,express_yangdengliu e
where e.oid=d.oid
end
go

