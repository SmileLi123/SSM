--判断是否还有数量
create proc P_JudgeCommodity(@cid int,@number int=1)
as
begin
if @cid is null 
	return 1
if dbo.F_queryNum(@cid)<@number
	return 2
else
	return 0
end
go

