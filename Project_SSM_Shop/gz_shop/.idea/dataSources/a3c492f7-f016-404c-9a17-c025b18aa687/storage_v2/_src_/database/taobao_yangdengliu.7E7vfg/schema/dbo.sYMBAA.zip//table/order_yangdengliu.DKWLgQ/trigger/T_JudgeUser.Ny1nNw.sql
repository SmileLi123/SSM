--在用户购买时判断是否有电话与地址
create trigger T_JudgeUser
on dbo.order_yangdengliu for update
as begin
declare @ad varchar(50),@ph char(12)
select @ad=u.home,@ph=u.phone
from user_yangdengliu u 
join order_yangdengliu o on u.uid=o.uid
if @ad is null or @ph is null
	begin
		rollback tran
	end
end
go

