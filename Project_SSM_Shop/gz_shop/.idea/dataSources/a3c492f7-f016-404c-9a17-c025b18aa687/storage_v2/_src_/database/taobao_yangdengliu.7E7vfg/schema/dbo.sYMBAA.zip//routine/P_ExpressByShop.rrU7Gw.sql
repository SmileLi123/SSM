create PROC P_ExpressByShop(@id int)
as
begin
set nocount on
declare @eid int,@send int,@date datetime
declare shop_cur cursor
for
select eid,send,date
from Express_yangdengliu
for update of send,date
open shop_cur
fetch next from shop_cur into @eid,@send,@date
while @@FETCH_STATUS=0
begin
	if @eid=@id 
		 update Express_yangdengliu
		 set send=1,date=getdate()
		 where current of shop_cur
		 fetch next from shop_cur into @eid,@send,@date
end
close shop_cur
deallocate shop_cur
end
go

