create function F_queryNum(@cid int)
returns int
as begin
	declare @number int
	select @number=num from commodity_yangdengliu c 
	where c.cid=@cid
	return @number
end
go

