create function F_ExpressByUser(@id int)
returns @OrderByUser table(
	eid int,
	oid int,
	uid int,
	cid int,
	sid int,
	cname varchar(30),
	sname varchar(30),
	price decimal(18, 0),
	number int,
	send int,
	accept int,
	date datetime,
	saddr varchar(50)
)
as
begin 
	insert @OrderByUser
	select e.eid, o.oid, uid,o.cid,c.sid,cname,sname,price,number,send,accept,date,s.address
	from order_yangdengliu o 
	join commodity_yangdengliu c on o.cid=c.cid
	join shopkeeper_yangdengliu s on s.sid=c.sid
	join express_yangdengliu e on e.oid=o.oid
	where o.uid=@id and o.buy=1
	return
end
go

