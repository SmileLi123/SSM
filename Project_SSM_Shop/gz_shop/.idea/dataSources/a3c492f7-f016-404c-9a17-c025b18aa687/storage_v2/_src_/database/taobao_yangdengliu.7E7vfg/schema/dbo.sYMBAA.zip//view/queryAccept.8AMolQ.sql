CREATE VIEW dbo.queryAcceptByUser
AS
SELECT     dbo.user_yangdengliu.uid, dbo.shopkeeper_yangdengliu.sname, dbo.order_yangdengliu.buy, dbo.commodity_yangdengliu.cname, dbo.commodity_yangdengliu.price, 
                      dbo.express_yangdengliu.eid, dbo.order_yangdengliu.oid, dbo.order_yangdengliu.cid, dbo.express_yangdengliu.accept, dbo.shopkeeper_yangdengliu.sid, dbo.user_yangdengliu.uname
FROM         dbo.commodity_yangdengliu INNER JOIN
                      dbo.order_yangdengliu ON dbo.commodity_yangdengliu.cid = dbo.order_yangdengliu.cid INNER JOIN
                      dbo.express_yangdengliu ON dbo.order_yangdengliu.oid = dbo.express_yangdengliu.oid INNER JOIN
                      dbo.shopkeeper_yangdengliu ON dbo.commodity_yangdengliu.sid = dbo.shopkeeper_yangdengliu.sid INNER JOIN
                      dbo.user_yangdengliu ON dbo.order_yangdengliu.uid = dbo.user_yangdengliu.uid
go

