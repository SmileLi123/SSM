create function F_ExpressByShop(@id int)
returns @ExpressByShop table(
	eid int,
	uid int,
	oid int,
	uname nchar(10),
	cname nvarchar(32),
	price decimal(18, 0),
	number int,
	home nvarchar(50),
	send int,
	accept int,
	date datetime
)
as
begin 
	insert @ExpressByShop
		select e.eid,o.uid,o.oid,u.uname,c.cname,c.price,o.number,u.home,e.send,e.accept,e.date
		from order_yangdengliu o
		join commodity_yangdengliu c on o.cid=c.cid
		join shopkeeper_yangdengliu s on s.sid=c.sid
		join user_yangdengliu u on u.uid=o.uid
		join express_yangdengliu e on e.oid=o.oid
		where s.sid=@id and o.buy=1 and e.send=1
	return
end
go

