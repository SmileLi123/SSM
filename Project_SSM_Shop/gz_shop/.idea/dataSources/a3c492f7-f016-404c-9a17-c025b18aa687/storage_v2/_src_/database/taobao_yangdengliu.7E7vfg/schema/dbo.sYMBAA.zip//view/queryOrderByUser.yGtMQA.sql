CREATE VIEW dbo.queryOrderByUser
AS
SELECT     dbo.user_yangdengliu.uid, dbo.shopkeeper_yangdengliu.sname, dbo.order_yangdengliu.buy, dbo.commodity_yangdengliu.cname, dbo.commodity_yangdengliu.price, 
                      dbo.commodity_yangdengliu.describe
FROM         dbo.commodity_yangdengliu INNER JOIN
                      dbo.order_yangdengliu ON dbo.commodity_yangdengliu.cid = dbo.order_yangdengliu.cid INNER JOIN
                      dbo.shopkeeper_yangdengliu ON dbo.commodity_yangdengliu.sid = dbo.shopkeeper_yangdengliu.sid INNER JOIN
                      dbo.user_yangdengliu ON dbo.order_yangdengliu.uid = dbo.user_yangdengliu.uid
go

