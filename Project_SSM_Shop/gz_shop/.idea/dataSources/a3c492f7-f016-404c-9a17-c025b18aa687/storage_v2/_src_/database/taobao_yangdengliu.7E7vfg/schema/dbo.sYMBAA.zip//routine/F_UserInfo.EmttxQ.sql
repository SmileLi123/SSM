create function F_UserInfo(@id int)
returns table
as 
return (
select * from user_yangdengliu 
where uid=@id)
go

