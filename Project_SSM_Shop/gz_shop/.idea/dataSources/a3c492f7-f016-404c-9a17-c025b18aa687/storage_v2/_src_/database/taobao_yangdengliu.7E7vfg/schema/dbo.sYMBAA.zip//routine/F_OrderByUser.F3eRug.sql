create function F_OrderByUser(@id int)
returns @OrderByUser table(
	oid int,
	uid int,
	cid int,
	sid int,
	cname nvarchar(50),
	sname nvarchar(30),
	price decimal(18, 0),
	number int
)
as
begin 
	insert @OrderByUser
	select o.oid, uid,o.cid,c.sid,cname,sname,price,number
	from order_yangdengliu o 
	join commodity_yangdengliu c on o.cid=c.cid
	join shopkeeper_yangdengliu s on s.sid=c.sid
	where o.uid=@id and o.buy=0
	return
end
go

