create function F_OrderByShop(@id int)
returns @OrderByShop table(
	eid int,
	uid int,
	oid int,
	uname nchar(10),
	cname nvarchar(32),
	price decimal(18, 0),
	number int,
	home nvarchar(50)
)
as
begin 
	insert @OrderByShop
		select e.eid,o.uid,o.oid,u.uname,c.cname,c.price,o.number,u.home
		from order_yangdengliu o
		join commodity_yangdengliu c on o.cid=c.cid
		join shopkeeper_yangdengliu s on s.sid=c.sid
		join user_yangdengliu u on u.uid=o.uid
		join express_yangdengliu e on e.oid=o.oid
		where s.sid=@id and o.buy=1
	return
end
go

