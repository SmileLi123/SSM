create proc P_updateOrder(@cid int,@oid int)
as
begin try
	begin tran
	declare @return_status int,@number int
	select @number=number from order_yangdengliu where oid=@oid
	exec @return_status=P_JudgeCommodity @cid,@number
	if @return_status=0
		update order_yangdengliu set buy=1 where oid=@oid
		update commodity_yangdengliu set num=(num-@number) where cid=@cid
		insert into express_yangdengliu(oid,uaddr,saddr) 
			select o.oid,u.home ,s.address
			from order_yangdengliu as o 
			join commodity_yangdengliu c on o.cid=c.cid
			join shopkeeper_yangdengliu s on s.sid=c.sid
			join user_yangdengliu u on u.uid=o.uid
			where o.oid=@oid
		commit tran
end try
begin catch
	rollback tran
end catch
go

