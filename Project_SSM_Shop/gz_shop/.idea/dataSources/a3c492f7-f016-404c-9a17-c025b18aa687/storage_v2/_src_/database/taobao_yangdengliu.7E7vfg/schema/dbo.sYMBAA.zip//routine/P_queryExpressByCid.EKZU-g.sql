create proc P_queryExpressByCid(@cid int, @num int output)
as
begin 
	select @num=COUNT(1) from express_yangdengliu e 
	join order_yangdengliu o on e.oid=o.oid
	where o.cid=@cid and o.buy=0
	return 
end
go

