create proc P_addAppraise(@describe varchar(50),@eid int)
as
begin try
	begin tran
	declare @uid int,@cid int
	select @uid=uid,@cid=cid from express_yangdengliu e join order_yangdengliu o on e.oid=o.oid where e.eid=@eid
	insert into appraise_yangdengliu values(@cid,@uid,@describe,GETDATE(),@eid)
	commit tran
end try
begin catch
	rollback tran
end catch
go

