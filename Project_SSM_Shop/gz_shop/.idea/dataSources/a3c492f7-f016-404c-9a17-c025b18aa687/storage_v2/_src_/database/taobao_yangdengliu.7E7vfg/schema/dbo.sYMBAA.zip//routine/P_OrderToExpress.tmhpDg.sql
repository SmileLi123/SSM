create proc P_OrderToExpress
as
begin try
	begin tran
	insert into express_yangdengliu(oid,uaddr,saddr) 
		select o.oid,u.home ,s.address
		from order_yangdengliu as o 
		join commodity_yangdengliu c on o.cid=c.cid
		join shopkeeper_yangdengliu s on s.sid=c.sid
		join user_yangdengliu u on u.uid=o.uid
	commit tran
end try
begin catch
	rollback tran
end catch
go

