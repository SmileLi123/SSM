create proc P_deleteCommodity(@cid int)
as
begin try
	begin transaction
	declare @num int
	exec P_queryExpressByCid @cid, @num output
	delete commodity_yangdengliu where 0=@num and cid=@cid
	commit tran
end try
begin catch
	rollback tran
end catch
go

