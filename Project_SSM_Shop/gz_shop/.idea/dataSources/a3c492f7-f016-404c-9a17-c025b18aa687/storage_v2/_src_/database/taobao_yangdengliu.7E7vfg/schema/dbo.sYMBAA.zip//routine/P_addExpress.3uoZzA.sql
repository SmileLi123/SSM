create proc P_addExpress(@oid int)
as
insert into express_yangdengliu(oid,uaddr,saddr) 
select o.oid,u.home ,s.address
from order_yangdengliu as o 
join commodity_yangdengliu c on o.cid=c.cid
join shopkeeper_yangdengliu s on s.sid=c.sid
join user_yangdengliu u on u.uid=o.uid
where o.oid=@oid
go

